/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author kevin
 */
public interface ConsultasDAO {
     public ArrayList<EstudianteVO> consultarTabla();
    public EstudianteVO consultarID(int id);
    public void insertar(EstudianteVO evo);
    public void modificar(EstudianteVO evo);
    public EstudianteVO eliminar(int id);
}
