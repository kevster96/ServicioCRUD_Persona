/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author kevin
 */
public class Conector {
    private String driver ="com.mysql.jdbc.Driver";
    private String servidor ="127.0.0.1:3307";
    private String bd= "clase_Java";
    private String user="root";
    private String password="";
    private String cadena;
    
    Connection con;
    Statement st;
    
    
    public void conectar(){
    
        cadena ="jdbc:mysql://"+servidor+"/"+bd;
        try{
            Class.forName(driver).newInstance();
            con = DriverManager.getConnection(cadena,user,password);
        }catch(Exception e){
            System.err.println(""+e.getMessage());
        }
    }
    
   public int consulta_multiple(String consulta){
        int resulta;
        
        try {
            this.conectar();
            this.st = this.con.createStatement();
            resulta = this.st.executeUpdate(consulta);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            return 0;
        }
        return resulta;
    }
    
   public ResultSet consulta(String consulta){
        try{
            this.conectar();
            ResultSet respuesta = null;
            this.st = this.con.createStatement();
            respuesta = st.executeQuery(consulta);
            
            return respuesta;
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return null;
    }
    
    public void desconectar(){
        try{
            con.close();
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
    }
}

