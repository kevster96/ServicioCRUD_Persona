/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author kevin
 */
public class EstudianteDAO implements ConsultasDAO {
    
      public ArrayList<EstudianteVO> consultarTabla() {
       Conector con = new Conector();
       con.conectar();
       ArrayList<EstudianteVO> info = new ArrayList<>();
       ResultSet rs = con.consulta("SELECT * FROM estudiantes;");
       try{
           while(rs.next()){
           EstudianteVO evo = new EstudianteVO();
           evo.setId(rs.getInt(1));
           evo.setNombre(rs.getString(2));
           evo.setApellido(rs.getString(3));
           evo.setEdad(rs.getInt(4));
           evo.setNacionalidad(rs.getString(5));
           evo.setPunteo(rs.getInt(6));
           info.add(evo);
           }
       }catch(Exception e){
           System.err.println(""+e.getMessage());
       }
       con.desconectar();
       return info;
    }

    @Override
    public EstudianteVO consultarID(int id) {
          Conector con = new Conector();
          con.conectar();
          ResultSet rs = con.consulta("SELECT * FROM estudiantes WHERE id="+id+";");
          EstudianteVO evo = new EstudianteVO();
          try{
              
           while(rs.next()){
          
          evo.setId(rs.getInt(1));
           evo.setNombre(rs.getString(2));
           evo.setApellido(rs.getString(3));
           evo.setEdad(rs.getInt(4));
           evo.setNacionalidad(rs.getString(5));
           evo.setPunteo(rs.getInt(6));
          }
          }catch(Exception e){
         
          }
          con.desconectar();
          return evo;
    }

    @Override
    public void insertar(EstudianteVO evo) {
         Conector con = new Conector();
       con.conectar();
       try{
          con.consulta_multiple("INSERT INTO estudiantes (nombre, apellido, edad, nacionalidad, punteo)"
                  + " VALUES('"+evo.getNombre()+"','"
                  +evo.getApellido()+"',"
                  +evo.getEdad()+",'"
                  +evo.getNacionalidad()+"',"
                  +evo.getPunteo()+");");
       }catch(Exception e){
           System.err.println(e.getMessage());
       }
       con.desconectar();
       
    }

    @Override
    public void modificar(EstudianteVO evo) {
        Conector con = new Conector();
       con.conectar();
        try {
            con.consulta_multiple("UPDATE estudiantes SET nombre='"+evo.getNombre()+
                   "', apellido='"+evo.getApellido()+"', edad="+evo.getEdad()+
                    ", nacionalidad='"+evo.getNacionalidad()+"', punteo="+evo.getPunteo()+" WHERE id="+evo.getId()+";");
        } catch (Exception e) {
            
        }
    con.desconectar();
    }

    @Override
    public EstudianteVO eliminar(int id) {
           Conector con = new Conector();
       con.conectar();
       EstudianteVO evo = new EstudianteVO();
       try{
         con.consulta_multiple("DELETE FROM estudiantes WHERE id="+id+";");
       }catch(Exception e){
          
       }
       con.desconectar();
       return evo;
        }
    
}

    

