/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import Modelo.EstudianteDAO;
import Modelo.EstudianteVO;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author kevin
 */
@WebService(serviceName = "Service")
public class Service {

    EstudianteVO evo = new EstudianteVO();
    EstudianteDAO edao = new EstudianteDAO();
    /**
     * This is a sample web service operation
     */
     @WebMethod(operationName = "mostrar")
    public ArrayList<EstudianteVO> mostrar() {
        //TODO write your implementation code here:
        ArrayList datos =edao.consultarTabla();
        return datos;
    }
    
    
    
     @WebMethod(operationName = "insetar")
    
    public EstudianteVO insetar(
            @WebParam(name = "nombre") String nombre, 
            @WebParam(name = "apellido") String apellido, 
            @WebParam(name = "edad") int edad, 
            @WebParam(name = "nacionalidad") String nacionalidad, 
            @WebParam(name = "punteo") int punteo) {
        evo.setNombre(nombre);
        evo.setApellido(apellido);
        evo.setEdad(edad);
        evo.setNacionalidad(nacionalidad);
        evo.setPunteo(punteo);
        edao.insertar(evo);
        
        return evo;
        
    }

  
    @WebMethod(operationName = "consultaID")
    public EstudianteVO consultaID(@WebParam(name = "id") int id) {
        //TODO write your implementation code here:
        evo = edao.consultarID(id);
        return evo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "eliminar")
   
    public EstudianteVO eliminar(@WebParam(name = "id") int id) {
        evo =  edao.eliminar(id);
        return evo;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "modificar")
    public EstudianteVO modificar(
            @WebParam(name = "id") int id,
            @WebParam(name = "nombre") String nombre, 
            @WebParam(name = "apellido") String apellido, 
            @WebParam(name = "edad") int edad, 
            @WebParam(name = "nacionalidad") String nacionalidad, 
            @WebParam(name = "punteo") int punteo) {
        //TODO write your implementation code here:
        evo.setId(id);
        evo.setNombre(nombre);
        evo.setApellido(apellido);
        evo.setEdad(edad);
        evo.setNacionalidad(nacionalidad);
        evo.setPunteo(punteo);
        edao.modificar(evo);
        return evo;
    }
}
